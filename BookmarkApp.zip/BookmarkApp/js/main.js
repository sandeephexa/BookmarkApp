// add event listener
document.getElementById('myForm').addEventListener('submit',saveBookmark);

function saveBookmark(e){
    const siteName = document.getElementById('siteName').value;
    const siteUrl = document.getElementById('siteUrl').value;
   if(!validateForm(siteName,siteUrl)){
       document.getElementById('myForm').reset();
       return false;
   }

    var bookmark = {
        name : siteName,
        url : siteUrl
    }
  
    if(localStorage.getItem('bookmarks') === null){
        var bookmarks = [];
        bookmarks.push(bookmark);
        
        localStorage.setItem('bookmarks',JSON.stringify(bookmarks));
    }
    else{
        var bookmarks = JSON.parse(localStorage.getItem('bookmarks'));
        bookmarks.push(bookmark);
       
        localStorage.setItem('bookmarks',JSON.stringify(bookmarks));
    }
        //clearFields();
       document.getElementById('myForm').reset();

       fetchBookmarks();
      
    e.preventDefault();
}

// deleteBookmark
function deleteBookmark(url){

    var bookmarks = JSON.parse(localStorage.getItem('bookmarks'));
    // loop through bookmarks
    bookmarks.forEach(function(bookmark,index){
        if(bookmark.url === url){
            bookmarks.splice(index,1);
        }
    });

    // reset bookmarks array to local storage
    localStorage.setItem('bookmarks',JSON.stringify(bookmarks));
    // re-fetch bookmarks
    fetchBookmarks();
}

// fetch bookmarks
function fetchBookmarks(){

    var bookmarks = JSON.parse(localStorage.getItem('bookmarks'));
    // get output ID
    var bookmarksResults = document.getElementById('bookmarksResults');
    bookmarksResults.innerHTML = '';
    // loop through bookmarks
    for(var i=0;i<bookmarks.length;i++){

        var name = bookmarks[i].name;
         var url = bookmarks[i].url;
         bookmarksResults.innerHTML += '<div class="card card-block bg-faded">'+
                                  '<div class="card-body">'+
                                  '<h3>'+name+
                                  ' <a class="btn btn-primary" target="_blank" href="'+url+'">Visit</a> ' +
                                  ' <a onclick="deleteBookmark(\''+url+'\')" class="btn btn-danger" href="#">Delete</a> ' +
                                  '</h3>'+
                                  '</div>'+
                                  '</div>';
    }
}

// validateForm
function validateForm(siteName,siteUrl){
     // validate fields
    if(!siteName || !siteUrl){
        alert("please fill in all the fields");
        return false;
    }
    // regex for URL 
    var expression = /[-a-zA-Z0-9@:%_\+.~#?&//=]{2,256}\.[a-z]{2,4}\b(\/[-a-zA-Z0-9@:%_\+.~#?&//=]*)?/gi;
    var regex = new RegExp(expression);

    if(!siteUrl.match(regex))
    {
        alert('please use valid URL');
        return false;
    }

    return true;
}

// // clear Fields after adding bookmark
// function clearFields(){
//     const siteName = document.getElementById('siteName').value = '';
//     const siteUrl = document.getElementById('siteUrl').value = '';
// }
